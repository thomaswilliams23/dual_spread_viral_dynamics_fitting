sweep1_vals = {'0.9'};%{'0.1', '0.5', '0.9'};
rep_vals = {'1', '2', '3', '4'};

for ind1 = 1:length(sweep1_vals)
    sweep1 = sweep1_vals{ind1};

    fldr = strcat('fits_Pcc_', sweep1, '_cumul_I_only');

    Pcc_WMs = zeros(1,4);
    peak_WMs = zeros(1,4);

    for ind2 = 1:length(rep_vals)
        rep = rep_vals{ind2};


        load(strcat(fldr, '/replicate_', rep, '/curr_weights'));
        load(strcat(fldr, '/replicate_', rep, '/final_Pcc_samples'));
        load(strcat(fldr, '/replicate_', rep, '/final_peak_samples'));

        Pcc_WMs(ind2) = sum(curr_weights.*final_Pcc_samples);
        peak_WMs(ind2) = sum(curr_weights.*final_peak_samples);

        save(strcat(fldr, '/Pcc_WMs'), 'Pcc_WMs');
        save(strcat(fldr, '/peak_WMs'), 'peak_WMs');
    end


end
