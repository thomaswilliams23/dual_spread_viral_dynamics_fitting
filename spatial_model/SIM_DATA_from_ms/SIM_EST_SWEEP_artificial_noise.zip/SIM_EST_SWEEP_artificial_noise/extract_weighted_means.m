sweep1_vals = {'1e1', '1e2', '1e3', '1e4'};
rep_vals = {'1', '2', '3', '4'};

for ind1 = 1:length(sweep1_vals)
    sweep1 = sweep1_vals{ind1};

    fldr = strcat('dispersion_param_', sweep1);

    Pcc_WMs = zeros(1,4);
    peak_WMs = zeros(1,4);

    for ind3 = 1:length(rep_vals)
        rep = rep_vals{ind3};


        load(strcat(fldr, '/replicate_', rep, '/curr_weights'));
        load(strcat(fldr, '/replicate_', rep, '/final_Pcc_samples'));
        load(strcat(fldr, '/replicate_', rep, '/final_peak_samples'));

        Pcc_WMs(ind3) = sum(curr_weights.*final_Pcc_samples);
        peak_WMs(ind3) = sum(curr_weights.*final_peak_samples);

        save(strcat(fldr, '/Pcc_WMs'), 'Pcc_WMs');
        save(strcat(fldr, '/peak_WMs'), 'peak_WMs');
    end

end

